
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import java.sql.PreparedStatement;

import javax.swing.JTextField;

public class billt2 extends JFrame implements ActionListener {

    JTextArea ta1;
    JLabel l1, l2, l3, l4, l5, l6;
    JTextField j1, j2, j3, j4, j5;
    JButton back, cart, view, ft, remove;
    JScrollPane p;
    Font f;

    billt2() {

        f = new Font("Arial", Font.BOLD, 17);

        l6 = new JLabel("TABLE NO: 2");
        l6.setBounds(400, 30, 300, 30);

        ta1 = new JTextArea();
        p = new JScrollPane(ta1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        p.setBounds(500, 100, 350, 500);

        l4 = new JLabel("Enter Customer Id: ");
        l4.setBounds(30, 100, 300, 30);
        j4 = new JTextField();
        j4.setBounds(200, 100, 200, 30);

        l5 = new JLabel("Enter Date: ");
        l5.setBounds(30, 150, 300, 30);
        j5 = new JTextField("2023-03-17");
        j5.setBounds(200, 150, 200, 30);

        l1 = new JLabel("Enter ID item: ");
        l1.setBounds(30, 200, 300, 30);
        j1 = new JTextField();
        j1.setBounds(200, 200, 200, 30);

        l2 = new JLabel("Enter Quantity: ");
        l2.setBounds(30, 250, 300, 30);
        j2 = new JTextField();
        j2.setBounds(200, 250, 200, 30);

        l3 = new JLabel("Enter ID To Cancle: ");
        l3.setBounds(30, 300, 300, 30);
        j3 = new JTextField();
        j3.setBounds(200, 300, 200, 30);

        back = new JButton("Back");
        back.setBounds(20, 400, 100, 30);
        back.addActionListener(this);

        remove = new JButton("Remove");
        remove.setBounds(320, 400, 100, 30);
        remove.addActionListener(this);

        cart = new JButton("ADD to Cart");
        cart.setBounds(200, 400, 100, 30);
        cart.addActionListener(this);

        view = new JButton("View");
        view.setBounds(20, 450, 100, 30);
        view.addActionListener(this);

        ft = new JButton("Bill");
        ft.setBounds(200, 450, 100, 30);
        ft.addActionListener(this);

        l1.setFont(f);
        l2.setFont(f);
        l3.setFont(f);
        l4.setFont(f);
        l5.setFont(f);
        l6.setFont(f);

        j1.setFont(f);
        j2.setFont(f);
        j3.setFont(f);
        j4.setFont(f);
        j5.setFont(f);

        ta1.setFont(f);

        l1.setForeground(Color.WHITE);
        l2.setForeground(Color.WHITE);
        l3.setForeground(Color.WHITE);
        l4.setForeground(Color.WHITE);
        l5.setForeground(Color.WHITE);
        l6.setForeground(Color.WHITE);

        add(back);
        add(cart);
        add(ft);
        add(view);
        add(j1);
        add(j2);
        add(j3);
        add(l1);
        add(l2);
        add(l3);
        add(remove);
        add(l4);
        add(l6);
        add(j4);
        add(l5);
        add(j5);
        add(p);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        new billt2();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back) {

            new w1();
        }

        if (e.getSource() == ft) {

            new bill2t2();
        }

        if (e.getSource() == cart) {

            if (!j4.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else if (!j5.getText().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                JOptionPane.showMessageDialog(null, "Please enter date in this  format 2023-03-02 !");
            } else if (!j1.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter valid number !");
            } else if ((!j2.getText().matches("[0-9]+"))) {
                JOptionPane.showMessageDialog(null, "Please enter valid number !");
            } else {

                try {
                    String id = j1.getText();
                    int que = Integer.parseInt(j2.getText());

                    String id1, name;
                    int price;
                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                    Statement stmt = con.createStatement();

                    PreparedStatement ps1 = null, ps2 = null;

                    ResultSet rs = null;
                    rs = stmt.executeQuery("select * from menu where menuid = " + id);

                    ps1 = con.prepareStatement("insert into billt2 values(?,?,?,?,?,?);");
                    ps2 = con.prepareStatement("insert into bill2t2 values(?,?,?);");

                    while (rs.next()) {

                        id1 = rs.getString(1);
                        name = rs.getString(2);
                        price = rs.getInt(3);

                        ps1.setString(1, j5.getText());
                        ps1.setInt(2, Integer.parseInt(j4.getText()));
                        ps1.setInt(3, Integer.parseInt(id1));
                        ps1.setString(4, name);
                        ps1.setInt(5, que);
                        ps1.setInt(6, price);

                        ps2.setInt(1, Integer.parseInt(id1));
                        ps2.setString(2, name);
                        ps2.setInt(3, que);

                        ps1.executeUpdate();
                        ps2.executeUpdate();
                    }

                } catch (Exception p) {
                    System.out.println("Error: " + p);
                }
            }

        }
        if (e.getSource() == remove) {
            int a = Integer.parseInt(j3.getText());
            String da = j5.getText();
            int cust = Integer.parseInt(j4.getText());

            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                Statement stmt = con.createStatement();
                stmt.executeUpdate("delete from bill2t2 where item_id = " + a);

                String sql = "DELETE FROM Billt2 WHERE order_date=? AND  customer_id=? AND item_id=?";
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setString(1, da);
                pstmt.setInt(2, cust);
                pstmt.setInt(3, a);

                pstmt.executeUpdate();

            } catch (Exception q) {
                System.out.println("Error: " + q);
            }
        }

        if (e.getSource() == view) {
            int price, id;
            String name;
            String date = j5.getText();
            int custid = Integer.parseInt(j4.getText());

            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");

                String query = "SELECT * FROM billt2 WHERE order_date = ? AND customer_id = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, date);
                ps.setInt(2, custid);
                ResultSet rs = ps.executeQuery();

                ta1.setText(null);

                while (rs.next()) {
                    id = rs.getInt(3);
                    name = rs.getString(4);
                    price = rs.getInt(6);

                    ta1.append(" " + id + "  " + name + "\t" + price + "\n");
                }

            } catch (Exception q) {
                System.out.println("Error: " + q);
            }
        }

    }

}
