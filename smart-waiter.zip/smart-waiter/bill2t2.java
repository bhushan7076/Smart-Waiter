import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.sql.*;
import java.awt.Font;
import java.sql.PreparedStatement;

import javax.swing.JTextField;

public class bill2t2 extends JFrame implements ActionListener {
    JTextArea jt1;
    JScrollPane p;
    JLabel l, l4, l5;
    JButton payment, view, back;
    JTextField j4, j5;
    Font f, f1;

    bill2t2() {
        f = new Font("Arial", Font.BOLD, 12);
        f1 = new Font("Arial", Font.BOLD, 17);

        l = new JLabel("TABLE 1 BILL");
        l.setBounds(400, 0, 200, 100);

        jt1 = new JTextArea();
        p = new JScrollPane(jt1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        p.setBounds(100, 150, 650, 430);

        payment = new JButton("Payment");
        payment.setBounds(330, 600, 100, 30);
        payment.addActionListener(this);

        view = new JButton("View");
        view.setBounds(450, 600, 100, 30);
        view.addActionListener(this);

        back = new JButton("Back");
        back.setBounds(200, 600, 100, 30);
        back.addActionListener(this);

        l4 = new JLabel("Enter " + "\n" + " Customer Id: ");
        l4.setBounds(100, 100, 300, 30);
        j4 = new JTextField();
        j4.setBounds(220, 100, 200, 30);

        l5 = new JLabel("Enter Date: ");
        l5.setBounds(450, 100, 300, 30);
        j5 = new JTextField("2023-03-17");
        j5.setBounds(550, 100, 200, 30);

        l.setFont(f1);
        l4.setFont(f);
        l5.setFont(f);

        l.setForeground(Color.WHITE);
        l4.setForeground(Color.WHITE);
        l5.setForeground(Color.WHITE);

        j4.setFont(f1);
        j5.setFont(f1);
        jt1.setFont(f1);

        add(p);
        add(l);
        add(payment);
        add(view);
        add(l4);
        add(l5);
        add(j4);
        add(j5);
        add(back);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        new bill2t2();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == payment) {
            this.dispose();
            new payment();
        }

        if (e.getSource() == back) {
            this.dispose();
            new billt2();
        }

        if (e.getSource() == view)

        {

            if (!j4.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else if (!j5.getText().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                JOptionPane.showMessageDialog(null, "Please enter date in this  format 2023-03-02 !");
            } else {

                try {
                    int price, id = 0, qua, total, ftotal = 0;
                    String name;
                    String date = j5.getText();
                    int custid = Integer.parseInt(j4.getText());

                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");

                    String query = "SELECT * FROM billt2 WHERE order_date = ? AND customer_id = ?";
                    PreparedStatement ps = con.prepareStatement(query);
                    ps.setString(1, date);
                    ps.setInt(2, custid);
                    ResultSet rs = ps.executeQuery();

                    jt1.setText(null);

                    jt1.append(
                            "******************************************************************************************************\n");
                    jt1.append("HOTEL VEDANT\n");
                    jt1.append("Date:- " + date);
                    jt1.append("\nCustomer id:- " + custid);
                    jt1.append(
                            "\n*****************************************************************************************************\n");
                    jt1.append(" ID" + "\tNAME" + "\t\tPRICE" + "\tQUANTITY" + "\tTOTAL\n\n");
                    while (rs.next()) {
                        id++;
                        name = rs.getString(4);
                        qua = rs.getInt(5);
                        price = rs.getInt(6);
                        total = qua * price;
                        ftotal = total + ftotal;

                        jt1.append(" " + id + "\t" + name + "\t\t" + price + "\t" + qua + "\t" + total + "\n");
                    }
                    jt1.append(
                            "*******************************************************************************************************\n");
                    jt1.append("FINAL TOTAL:  " + ftotal);
                    jt1.append(
                            "\n*******************************************************************************************************\n");
                } catch (Exception q) {
                    System.out.println("Error: " + q);
                }
            }
        }
    }
}
