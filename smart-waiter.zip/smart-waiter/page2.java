
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
//import javax.swing.JPasswordField;

//import javax.swing.*;

public class page2 extends JFrame implements ActionListener {
    JButton b1, b2, b3, b4, b5;

    page2() {
        Font f1 = new Font("Arial", Font.BOLD, 15);

        b1 = new JButton("Modify Waiter");
        b2 = new JButton("Modify Kitchen");
        // b3 = new JButton("Report");
        b4 = new JButton("Logout");
        b5 = new JButton("Modify Menu");

        b1.setFont(f1);
        b2.setFont(f1);
        // b3.setFont(f1);
        b4.setFont(f1);
        b5.setFont(f1);

        b1.setBounds(200, 200, 200, 70);
        b2.setBounds(420, 200, 200, 70);
        // b3.setBounds(200, 300, 200, 70);
        b4.setBounds(340, 500, 150, 30);
        b5.setBounds(300, 300, 200, 70);

        b1.addActionListener(this);
        b2.addActionListener(this);
        // b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);

        add(b1);
        add(b2);
        // add(b3);
        add(b4);
        add(b5);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        new page2();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            this.dispose();
            new addwaiter();
        }
        if (e.getSource() == b2) {
            this.dispose();
            new addkadmin();
        }
        // if (e.getSource() == b3) {
        // this.dispose();
        // new payment();
        // }
        if (e.getSource() == b4) {
            this.dispose();
            new index();
        }
        if (e.getSource() == b5) {
            this.dispose();
            new menu();
        }

    }

}
