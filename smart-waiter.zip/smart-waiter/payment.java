
//Java Program to Add Image in Jframe 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class payment extends JFrame implements ActionListener {
    ImageIcon img1;
    JLabel id;
    JLabel t;
    JButton b;
    Font f;

    payment() {
        f = new Font("Arial", Font.BOLD, 25);
        img1 = new ImageIcon("pay.jpeg");
        id = new JLabel("", img1, JLabel.CENTER);
        t = new JLabel("Thank You!! Visit Again");
        t.setBounds(250, 400, 300, 100);
        id.setSize(300, 300);
        id.setBounds(250, 100, 300, 300);
        b = new JButton("Back");
        b.setBounds(340, 540, 100, 30);
        b.addActionListener(this);

        t.setFont(f);
        t.setForeground(Color.white);

        add(b);
        add(id);
        add(t);
        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {

        new payment();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b) {
            this.dispose();
            new bill2();
        }

    }
}