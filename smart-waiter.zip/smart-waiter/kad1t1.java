import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.*;

public class kad1t1 extends JFrame implements ActionListener {
    JTextArea j1;
    JLabel l1;
    JButton b, b2, b3;
    JScrollPane p;
    Font f, f1;

    kad1t1() {
        f = new Font("Arial", Font.BOLD, 25);
        f1 = new Font("Arial", Font.BOLD, 15);

        j1 = new JTextArea();
        p = new JScrollPane(j1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        p.setBounds(150, 100, 550, 450);
        j1.setFont(f1);

        l1 = new JLabel("Table 1 Order");
        l1.setBounds(320, 20, 200, 20);
        l1.setFont(f);
        l1.setForeground(Color.white);

        b = new JButton("Back");
        b.setBounds(150, 600, 100, 40);
        b.addActionListener(this);

        b2 = new JButton("View");
        b2.setBounds(380, 600, 100, 40);
        b2.addActionListener(this);

        b3 = new JButton("Done");
        b3.setBounds(600, 600, 100, 40);
        b3.addActionListener(this);

        add(p);
        add(l1);
        add(b);
        add(b3);
        add(b2);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        new kad1t1();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b) {

            new kad1();
            this.dispose();
        }

        if (e.getSource() == b3) {

            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                Statement stmt = con.createStatement();
                stmt.executeUpdate("DELETE FROM bill2");

            } catch (Exception q) {
                System.out.println("Error: " + q);
            }
        }

        if (e.getSource() == b2) {
            int id, qua;
            String name;

            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                Statement stmt = con.createStatement();
                ResultSet rs = null;
                rs = stmt.executeQuery("select * from bill2 ");

                j1.setText(null);

                j1.append("ID" + "\t\t" + "Name" + "\t\t" + "Quantity \n");

                while (rs.next()) {

                    id = rs.getInt(1);
                    name = rs.getString(2);
                    qua = rs.getInt(3);

                    j1.append(id + "\t\t" + name + "\t\t" + qua + "\n");

                }

            } catch (Exception q) {
                System.out.println("Error: " + q);
            }
        }
    }
}
