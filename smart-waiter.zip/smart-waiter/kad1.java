import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class kad1 extends JFrame implements ActionListener {

    JButton t1, t2, t3, t4, t5, t6, t7, t8, back;
    Font f;

    kad1() {

        f = new Font("Arial", Font.BOLD, 25);

        JLabel l1;
        l1 = new JLabel("Select Table ");
        l1.setBounds(280, 20, 200, 80);
        l1.setFont(f);
        l1.setForeground(Color.white);
        add(l1);

        t1 = new JButton("Table 1");
        t1.setBounds(100, 100, 200, 70);
        t1.addActionListener(this);
        t2 = new JButton("Table 2");
        t2.setBounds(400, 100, 200, 70);
        t2.addActionListener(this);
        t3 = new JButton("Table 3");
        t3.setBounds(100, 200, 200, 70);
        t4 = new JButton("Table 4");
        t4.setBounds(400, 200, 200, 70);
        t5 = new JButton("Table 5");
        t5.setBounds(100, 350, 200, 70);
        t6 = new JButton("Table 6");
        t6.setBounds(400, 350, 200, 70);
        t7 = new JButton("Table 7");
        t7.setBounds(100, 450, 200, 70);
        t8 = new JButton("Table 8");
        t8.setBounds(400, 450, 200, 70);
        back = new JButton("Back");
        back.setBounds(280, 550, 150, 40);
        back.addActionListener(this);

        add(t1);
        add(t2);
        add(t3);
        add(t4);
        add(t5);
        add(t6);
        add(t7);
        add(t8);
        add(back);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {

        new kad1();

    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == back) {
            this.dispose();
            new index();
        }
        if (e.getSource() == t1) {

            this.dispose();
            new kad1t1();

        }
        if (e.getSource() == t2) {

            this.dispose();
            new kad1t2();

        }

    }

}
