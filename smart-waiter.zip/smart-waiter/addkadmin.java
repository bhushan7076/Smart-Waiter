import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.awt.*;

public class addkadmin extends JFrame implements ActionListener {
    JLabel l1, l2, l3, l4, l5, l6, l7;
    JTextField j1, j2, j3, j4, j5, j6;
    JButton b1, b2, b4, b5;
    JTextArea jt1;
    JScrollPane p;

    Font f, f1;

    addkadmin() {
        f = new Font("Arial", Font.BOLD, 13);
        f1 = new Font("Arial", Font.BOLD, 16);

        l7 = new JLabel("-:  Kitchen Admin data  :-");
        l7.setBounds(600, 50, 200, 30);

        l1 = new JLabel("Enter ID: ");
        l1.setBounds(50, 50, 100, 30);
        j1 = new JTextField();
        j1.setBounds(200, 50, 200, 30);

        l2 = new JLabel("Enter Name: ");
        l2.setBounds(50, 100, 100, 30);
        j2 = new JTextField();
        j2.setBounds(200, 100, 200, 30);

        l3 = new JLabel("Enter Mobile Number: ");
        l3.setBounds(50, 150, 150, 30);
        j3 = new JTextField();
        j3.setBounds(200, 150, 200, 30);

        l4 = new JLabel("Enter Addhar Number: ");
        l4.setBounds(50, 200, 150, 30);
        j4 = new JTextField();
        j4.setBounds(200, 200, 200, 30);

        l5 = new JLabel("Enter Address: ");
        l5.setBounds(50, 250, 150, 30);
        j5 = new JTextField();
        j5.setBounds(200, 250, 200, 30);

        l6 = new JLabel("Enter ID to delete: ");
        l6.setBounds(50, 300, 150, 30);
        j6 = new JTextField();
        j6.setBounds(200, 300, 200, 30);

        b1 = new JButton("ADD Kitchen Admin");
        b1.setBounds(50, 400, 150, 50);
        b1.addActionListener(this);
        b2 = new JButton("Remove Kitchen Admin");
        b2.setBounds(220, 400, 190, 50);
        b2.addActionListener(this);

        b4 = new JButton("Back");
        b4.setBounds(50, 500, 150, 40);
        b4.addActionListener(this);

        b5 = new JButton("View");
        b5.setBounds(220, 500, 190, 40);
        b5.addActionListener(this);

        jt1 = new JTextArea();
        p = new JScrollPane(jt1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        p.setBounds(500, 100, 350, 500);

        l1.setFont(f);
        l2.setFont(f);
        l3.setFont(f);
        l4.setFont(f);
        l5.setFont(f);
        l6.setFont(f);
        l7.setFont(f1);

        j1.setFont(f1);
        j2.setFont(f1);
        j3.setFont(f1);
        j4.setFont(f1);
        j5.setFont(f1);
        j6.setFont(f1);

        l1.setForeground(Color.white);
        l3.setForeground(Color.white);
        l2.setForeground(Color.white);
        l4.setForeground(Color.white);
        l5.setForeground(Color.white);
        l6.setForeground(Color.white);
        l7.setForeground(Color.white);

        add(l1);
        add(l2);
        add(l3);
        add(l4);
        add(l5);
        add(j1);
        add(j2);
        add(j3);
        add(j4);
        add(j5);
        add(l6);
        add(j6);
        add(b1);
        add(b2);
        // add(jt1);
        add(l7);
        add(b4);
        add(b5);
        add(p);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {
        new addkadmin();
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b4) {
            this.dispose();
            new page2();
        }

        if (e.getSource() == b1) {
            if (!j1.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else if (!j2.getText().matches("[a-z A-Z]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid Name !");
            } else if ((j3.getText().length() != 10) || (!j3.getText().matches("[0-9]+"))) {
                JOptionPane.showMessageDialog(null, "Please enter valid mobile number !");
            } else if ((j4.getText().length() != 12) || (!j4.getText().matches("[0-9]+"))) {
                JOptionPane.showMessageDialog(null, "Please enter valid addhar number !");
            } else if (!j5.getText().matches("[a-z A-Z]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid address !");
            } else {

                try {
                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                    PreparedStatement ps1 = null;
                    ps1 = con.prepareStatement("insert into kitchen_admin values(?,?,?,?,?);");

                    ps1.setInt(1, Integer.parseInt(j1.getText()));
                    ps1.setString(2, j2.getText());
                    ps1.setLong(3, Long.parseLong(j3.getText()));
                    ps1.setLong(4, Long.parseLong(j4.getText()));
                    ps1.setString(5, j5.getText());
                    ps1.executeUpdate();

                } catch (Exception p) {
                    JOptionPane.showMessageDialog(null, p);
                }
            }
        }

        if (e.getSource() == b2) {

            if (!j6.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else {
                try {
                    int a = Integer.parseInt(j6.getText());
                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                    Statement stmt = con.createStatement();
                    stmt.executeUpdate("delete from kitchen_admin where kadmin_id = " + a);

                } catch (Exception q) {
                    JOptionPane.showMessageDialog(null, q);
                }
            }
        }

        if (e.getSource() == b5) {
            int id1;
            String name, add;
            BigDecimal ano, mno;
            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                Statement stmt = con.createStatement();
                ResultSet rs = null;
                rs = stmt.executeQuery("select * from kitchen_admin ");

                jt1.setText(null);

                jt1.append(
                        "ID" + "   " + "Name" + "\t\t" + "    mobile no     " + "  " + "    aadhaar no     " + "  "
                                + "address"
                                + "\n");

                while (rs.next()) {

                    id1 = rs.getInt(1);
                    name = rs.getString(2);
                    mno = rs.getBigDecimal(3);
                    ano = rs.getBigDecimal(4);
                    add = rs.getString(5);

                    jt1.append(id1 + "   " + name + "\t\t" + mno + "  " + ano + "  " + add + "\n");

                }

            } catch (Exception q) {
                JOptionPane.showMessageDialog(null, q);
            }
        }
    }

}
