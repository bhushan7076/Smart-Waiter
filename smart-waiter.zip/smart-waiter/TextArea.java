
public class TextArea {

    public void setBounds(int i, int j, int k, int l) {
    }

    public void setText(Object object) {
    }

    public void append(String string) {
    }

}
