import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;

public class index extends JFrame implements ActionListener {
    JLabel l1, l2, id, l3;
    JButton b;
    JTextArea area;
    JPasswordField area1;
    Font f, f1;
    ImageIcon img1;

    index() {

        img1 = new ImageIcon("wallpaper.jpeg");
        id = new JLabel("", img1, JLabel.CENTER);
        id.setSize(500, 300);
        id.setBounds(80, 10, 700, 600);
        add(id);

        f = new Font("Arial", Font.BOLD, 17);
        f1 = new Font("Calibri", Font.BOLD, 50);

        l1 = new JLabel("Enter Username: ");
        l1.setBounds(230, 520, 150, 30);
        l2 = new JLabel("Enter Password: ");
        l2.setBounds(230, 580, 150, 30);
        l3 = new JLabel("HOTEL VEDANT PURE VEG");
        l3.setBounds(170, 30, 600, 50);
        l1.setFont(f);
        l2.setFont(f);
        l3.setFont(f1);

        l1.setForeground(Color.white);
        l2.setForeground(Color.white);
        l3.setForeground(Color.orange);

        add(l1);
        add(l2);
        add(l3);
        area = new JTextArea();
        area.setBounds(380, 520, 200, 30);
        area.setFont(f);
        add(area);

        area1 = new JPasswordField();
        area1.setFont(f);

        area1.setBounds(380, 580, 200, 30);
        add(area1);

        b = new JButton("submit");
        b.addActionListener(this);
        b.setBounds(320, 620, 100, 30);
        add(b);

        setLayout(null);
        setSize(900, 700);
        setVisible(true);
        getContentPane().setBackground(new Color(0, 119, 182));
    }

    public static void main(String[] args) {

        new index();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b) {
            String uid = "admin";
            String pwd = "admin@123";

            String w = "waiter";
            String pwdw = "waiter@123";

            String kad = "kitchen_admin";
            String pwdkad = "kad@123";

            String s = new String(area1.getPassword());

            if (uid.equals(area.getText()) && pwd.equals(s))

            {
                new page2();
                this.dispose();

            } else if (w.equals(area.getText()) && pwdw.equals(s))

            {
                new w1();
                this.dispose();

            } else if (kad.equals(area.getText()) && pwdkad.equals(s)) {
                new kad1();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Please Enter Valid information");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Please Enter Valid Credentials");
            l1.setText("");
            l2.setText("");

        }

    }

}