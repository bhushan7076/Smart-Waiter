import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.*;

public class menu extends JFrame implements ActionListener {
    JLabel l1, l2, l3, l4, l5, l6, l7;
    JTextField j1, j2, j3, j4, j5, j6, msg;
    JButton back, add, remove, view;
    JTextArea jt1;
    JScrollPane p;

    Font f, f1;

    menu() {
        f = new Font("Arial", Font.BOLD, 13);
        f1 = new Font("Arial", Font.BOLD, 16);

        l7 = new JLabel("-:  Menu data  :-");
        l7.setBounds(630, 50, 100, 30);

        l1 = new JLabel("Enter Menu ID: ");
        l1.setBounds(50, 150, 100, 30);
        j1 = new JTextField();
        j1.setBounds(200, 150, 200, 30);

        l2 = new JLabel("Enter Menu Name: ");
        l2.setBounds(50, 200, 140, 30);
        j2 = new JTextField();
        j2.setBounds(200, 200, 200, 30);

        l3 = new JLabel("Enter Price: ");
        l3.setBounds(50, 250, 150, 30);
        j3 = new JTextField();
        j3.setBounds(200, 250, 200, 30);

        l4 = new JLabel("Enter Id to delete: ");
        l4.setBounds(50, 300, 150, 30);
        j4 = new JTextField();
        j4.setBounds(200, 300, 200, 30);

        jt1 = new JTextArea();
        p = new JScrollPane(jt1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        p.setBounds(500, 100, 350, 500);

        add = new JButton("Add");
        add.setBounds(50, 400, 100, 30);
        add.addActionListener(this);

        remove = new JButton("Remove");
        remove.setBounds(250, 400, 100, 30);
        remove.addActionListener(this);

        back = new JButton("back");
        back.setBounds(50, 450, 100, 30);
        back.addActionListener(this);

        view = new JButton("view");
        view.setBounds(250, 450, 100, 30);
        view.addActionListener(this);

        l1.setFont(f);
        l2.setFont(f);
        l3.setFont(f);
        l4.setFont(f);
        l7.setFont(f);

        j1.setFont(f1);
        j2.setFont(f1);
        j3.setFont(f1);
        j4.setFont(f1);

        l1.setForeground(Color.white);
        l3.setForeground(Color.white);
        l2.setForeground(Color.white);
        l4.setForeground(Color.white);
        l7.setForeground(Color.white);

        add(l1);
        add(l2);
        add(l3);
        add(l4);
        add(p);
        add(j1);
        add(j2);
        add(j3);
        add(j4);
        add(l7);
        add(add);
        add(remove);
        add(view);
        add(back);

        getContentPane().setBackground(new Color(0, 119, 182));
        setLayout(null);
        setSize(900, 700);
        setVisible(true);
    }

    public static void main(String[] args) {

        new menu();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back) {
            this.dispose();
            new page2();
        }

        if (e.getSource() == add) {
            if (!j1.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else if (!j2.getText().matches("[a-z A-Z]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid Name !");
            }
            if (!j3.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else {
                try {
                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                    PreparedStatement ps1 = null;
                    ps1 = con.prepareStatement("insert into menu values(?,?,?);");

                    ps1.setInt(1, Integer.parseInt(j1.getText()));
                    ps1.setString(2, j2.getText());
                    ps1.setInt(3, Integer.parseInt(j3.getText()));
                    ps1.executeUpdate();

                } catch (Exception p) {
                    JOptionPane.showMessageDialog(null, p);
                }
            }
        }

        if (e.getSource() == remove) {

            if (!j4.getText().matches("[0-9]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number !");
            } else {
                try {
                    int a = Integer.parseInt(j4.getText());
                    Class.forName("org.gjt.mm.mysql.Driver");
                    Connection con = null;
                    con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                    Statement stmt = con.createStatement();
                    stmt.executeUpdate("delete from menu where menuid = " + a);

                } catch (Exception q) {
                    JOptionPane.showMessageDialog(null, q);
                }
            }
        }

        if (e.getSource() == view) {
            int id, price;
            String name;

            try {
                Class.forName("org.gjt.mm.mysql.Driver");
                Connection con = null;
                con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "bane");
                Statement stmt = con.createStatement();
                ResultSet rs = null;
                rs = stmt.executeQuery("select * from menu ");

                jt1.setText(null);

                jt1.append("ID" + "  " + "Name" + "\t\t" + "Price" + "\n");

                while (rs.next()) {

                    id = rs.getInt(1);
                    name = rs.getString(2);
                    price = rs.getInt(3);

                    jt1.append(id + "  " + name + "\t\t" + price + "\n");

                }

            } catch (Exception q) {
                JOptionPane.showMessageDialog(null, q);
            }
        }

    }
}
